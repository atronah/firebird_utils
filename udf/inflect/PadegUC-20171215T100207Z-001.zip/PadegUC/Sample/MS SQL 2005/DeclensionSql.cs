﻿using System;
using System.Data.SqlTypes;
using BLL.Declension;

public partial class DeclensionSql
{
    /// <summary>
    /// Данная функция является основной в библиотеке и наиболее универсальной. 
    /// В качестве параметров ей необходимо передать ФИО в виде трех строк (каждая из которых может 
    /// быть пустой), явно указанный род, требуемое значение падежа. 
    /// При таких условиях этой функцией можно склонять ФИО и его составляющие в любых комбинациях. 
    /// Корректно обрабатываются фамилии с инициалами (Сидоров И.П.) – склоняться будет только фамилия 
    /// (у Сидорова И.П.). Допускается использование инициалов, состоящих более чем из одного символа 
    /// (Иванов Вс.Никод.). Кроме ФИО славянского типа эта функция может выполнять склонение корейских, 
    /// китайских и им подобным имен. При этом первое слово в таком имени соответствует фамилии, 
    /// второе – имени и третье – отчеству в наших терминах. Другими словами, при склонении Иванов Иван 
    /// Иванович и Ли Си Цын не требуется перестановка составляющих ФИО. Поскольку имена подобного вида 
    /// иногда записывают двумя словами (Ли Сицын), то при вызове функции склонения для такой формы записи 
    /// необходимо первым параметром передать пустую строку. В подавляющем большинстве случаев эта функция 
    /// пригодна и для склонения ФИО, записанного в формате "Фамилия Имя [Имя]" (Кеннеди Джон [Фиджеральд]). 
    /// Допускается использование признаков рода в фамилии (-оглы/-кызы), записанных через дефис. 
    /// </summary>
    /// <param name="surname">Фамилия</param>
    /// <param name="name">Имя</param>
    /// <param name="patronimic">Отчество</param>
    /// <param name="gender">Пол</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetSNPDeclension(SqlString surname, SqlString name, SqlString patronimic, SqlInt32 gender,
                                              SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetSNPDeclension(surname.Value, name.Value, patronimic.Value, (Gender)Enum.Parse(typeof(Gender), gender.ToString()),
                                               (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция предназначена для склонения ФИО, род которых неизвестен. Определение рода осуществляется 
    /// по окончанию отчества. Корректно обрабатываются отчества, имеющие признак рода: Оглы (сын) или 
    /// Кызы (дочь). Признак рода может записываться через дефис (Аскер-Оглы) или пробел (Аскер Оглы). 
    /// </summary>
    /// <param name="surname">Фамилия</param>
    /// <param name="name">Имя</param>
    /// <param name="patronimic">Отчество</param>
    /// <param name="gender">Пол</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetSNPDeclension_WithoutGender(SqlString surname, SqlString name, SqlString patronimic,
                                          SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetSNPDeclension(surname.Value, name.Value, patronimic.Value, (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция выполняет преобразование ФИО, заданного одной строкой и требует явного указания рода. 
    /// Порядок следования составляющих ФИО в строке параметра – фамилия, имя, отчество. Эта функция, 
    /// как и GetSNPDeclension, тоже допускает использование инициалов и может выполнять преобразование имен 
    /// типа китайских. Для корректной работы функции необходимо наличие трех компонент ФИО 
    /// (имена китайского типа допускается задавать двумя словами). В ряде случаев правильно обрабатываются 
    /// ФИО, записанные в формате "Фамилия Имя [Имя]".
    /// </summary>
    /// <param name="surnameNamePatronimic">ФИО0</param>
    /// <param name="gender">Пол</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetSNPDeclension_WithFIO(SqlString surnameNamePatronimic, SqlInt32 gender,
                                          SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetSNPDeclension(surnameNamePatronimic.Value, (Gender)Enum.Parse(typeof(Gender), gender.ToString()),
                                               (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция предназначена для склонения ФИО, заданных одной строкой, род которых неизвестен. 
    /// Определение рода осуществляется по окончанию отчества. Функция корректно обрабатывает отчества, 
    /// имеющие признак рода: Оглы (сын) или Кызы (дочь). Признак рода может записываться через дефис 
    /// (Аскер-Оглы) или пробел (Аскер Оглы).
    /// </summary>
    /// <param name="name">Имя</param>
    /// <param name="surname">Фамилия</param>
    /// <param name="gender">Пол</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetNSDeclension(SqlString name, SqlString surname, SqlInt32 gender,
                                              SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetNSDeclension(name.Value, surname.Value, (Gender)Enum.Parse(typeof(Gender), gender.ToString()),
                                               (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция предназначена для склонения пар "Имя Фамилия" (Марк Твен) и требует явного указания рода. 
    /// Эта функция также пригодна для склонения имен собственных типа Джон Фиджеральд Кеннеди. 
    /// В этом случае Джон Фиджеральд следует передавать одним параметром, как имя. Разделитель слов в 
    /// параметре – пробел.
    /// </summary>
    /// <param name="nameSurname">ИФ</param>
    /// <param name="gender">Пол</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetNSDeclension_WithFIO(SqlString nameSurname, SqlInt32 gender,
                                              SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetNSDeclension(nameSurname.Value, (Gender)Enum.Parse(typeof(Gender), gender.ToString()),
                                               (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция выполняет восстановление именительного падежа для ФИО, заданного в произвольном падеже в 
    /// формате "Фамилия Имя Отчество".
    /// </summary>
    /// <param name="surnameNamePatronimic">ФИО</param>
    /// <returns>ФИО в именительном падеже</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetNominativeDeclension(SqlString surnameNamePatronimic)
    {
        return new SqlString(DeclensionBLL.GetNominativeDeclension(surnameNamePatronimic.Value));
    }

    /// <summary>
    /// Функция предназначена для склонения наименования должностей, записанных одной строкой. 
    /// Начиная с версии библиотеки 3.3.0.21 стала возможной обработка составных должностей. 
    /// Разделителем в этом случае должна быть цепочка символов: пробел, дефис, пробел (‘ - ’). 
    /// При этом, каждая из должностей в в своем составе может содержать дефис (инженер-конструктор).
    /// </summary>
    /// <param name="appointment">Название должности</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>        
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetAppointmentDeclension(SqlString appointment, SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetAppointmentDeclension(appointment.Value, (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция позволяет получить полное наименование должности и выполнить его преобразование в заданный 
    /// падеж. При объединении удаляются повторяющиеся слова при их наличии. Например: должность – 
    /// Начальник цеха; подразделение – Цех нестандартного оборудования; результат – Начальник цеха 
    /// нестандартного оборудования. 
    /// </summary>
    /// <param name="appointment">Название должности</param>
    /// <param name="office">Название подразделения</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>

    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetAppointmentOfficeDeclension(SqlString appointment, SqlString office, SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetAppointmentOfficeDeclension(appointment.Value, office.Value, (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }

    /// <summary>
    /// Функция предназначена для склонения наименования подразделений, записанных одной строкой. 
    /// Кроме подразделений функция также может выполнять склонение и наименований предприятий.
    /// </summary>
    /// <param name="office">Название подразделения</param>
    /// <param name="declensionCase">Падеж</param>
    /// <returns>Результат склонения</returns>
    [Microsoft.SqlServer.Server.SqlFunction(IsDeterministic = true, IsPrecise = true)]
    public static SqlString GetOfficeDeclension(SqlString office, SqlInt32 declensionCase)
    {
        return new SqlString(DeclensionBLL.GetOfficeDeclension(office.Value, (BLL.Declension.DeclensionCase)Enum.Parse(typeof(BLL.Declension.DeclensionCase), declensionCase.ToString())));
    }
};

