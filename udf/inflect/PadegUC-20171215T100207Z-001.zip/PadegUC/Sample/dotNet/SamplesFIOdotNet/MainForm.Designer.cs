﻿namespace SamplesFIOdotNet
{
    partial class MainForm
    {
        /// <summary>
        /// Требуется переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Обязательный метод для поддержки конструктора - не изменяйте
        /// содержимое данного метода при помощи редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.topLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.resultGB = new System.Windows.Forms.GroupBox();
            this.dipGB = new System.Windows.Forms.GroupBox();
            this.fioGB = new System.Windows.Forms.GroupBox();
            this.fioTextCB = new System.Windows.Forms.ComboBox();
            this.surnameLbl = new System.Windows.Forms.Label();
            this.surnameTB = new System.Windows.Forms.TextBox();
            this.nameTB = new System.Windows.Forms.TextBox();
            this.nameLbl = new System.Windows.Forms.Label();
            this.patronymicTB = new System.Windows.Forms.TextBox();
            this.patronymicLbl = new System.Windows.Forms.Label();
            this.splitFioBtn = new System.Windows.Forms.Button();
            this.clearFioBtn = new System.Windows.Forms.Button();
            this.sexCB = new System.Windows.Forms.ComboBox();
            this.sexLbl = new System.Windows.Forms.Label();
            this.detectSexBtn = new System.Windows.Forms.Button();
            this.descrFunctionTB = new System.Windows.Forms.TextBox();
            this.functionNameLbl = new System.Windows.Forms.Label();
            this.functionNameCB = new System.Windows.Forms.ComboBox();
            this.declineBtn = new System.Windows.Forms.Button();
            this.restoreNominativeDeclensionBtn = new System.Windows.Forms.Button();
            this.declensionCB = new System.Windows.Forms.ComboBox();
            this.genitiveTB = new System.Windows.Forms.TextBox();
            this.genitiveLbl = new System.Windows.Forms.Label();
            this.dativeTB = new System.Windows.Forms.TextBox();
            this.dativeLbl = new System.Windows.Forms.Label();
            this.accusativeTB = new System.Windows.Forms.TextBox();
            this.accusativeLbl = new System.Windows.Forms.Label();
            this.ablativeTB = new System.Windows.Forms.TextBox();
            this.ablativeLbl = new System.Windows.Forms.Label();
            this.prepositionalTB = new System.Windows.Forms.TextBox();
            this.prepositionalLbl = new System.Windows.Forms.Label();
            this.clearResultBtn = new System.Windows.Forms.Button();
            this.appointmenTB = new System.Windows.Forms.TextBox();
            this.appointmentLbl = new System.Windows.Forms.Label();
            this.officeTB = new System.Windows.Forms.TextBox();
            this.officeLbl = new System.Windows.Forms.Label();
            this.declineAppointmenBtn = new System.Windows.Forms.Button();
            this.declineOfficeBtn = new System.Windows.Forms.Button();
            this.declineAppointmenOfficeBtn = new System.Windows.Forms.Button();
            this.mainLayoutPanel1.SuspendLayout();
            this.topLayoutPanel1.SuspendLayout();
            this.resultGB.SuspendLayout();
            this.dipGB.SuspendLayout();
            this.fioGB.SuspendLayout();
            this.SuspendLayout();
            // 
            // mainLayoutPanel1
            // 
            this.mainLayoutPanel1.ColumnCount = 1;
            this.mainLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 48.44007F));
            this.mainLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 51.55993F));
            this.mainLayoutPanel1.Controls.Add(this.topLayoutPanel1, 0, 0);
            this.mainLayoutPanel1.Controls.Add(this.resultGB, 0, 1);
            this.mainLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.mainLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.mainLayoutPanel1.Name = "mainLayoutPanel1";
            this.mainLayoutPanel1.RowCount = 2;
            this.mainLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 61.21212F));
            this.mainLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 38.78788F));
            this.mainLayoutPanel1.Size = new System.Drawing.Size(720, 495);
            this.mainLayoutPanel1.TabIndex = 0;
            // 
            // topLayoutPanel1
            // 
            this.topLayoutPanel1.ColumnCount = 2;
            this.topLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.topLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.topLayoutPanel1.Controls.Add(this.dipGB, 1, 0);
            this.topLayoutPanel1.Controls.Add(this.fioGB, 0, 0);
            this.topLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.topLayoutPanel1.Location = new System.Drawing.Point(3, 3);
            this.topLayoutPanel1.Name = "topLayoutPanel1";
            this.topLayoutPanel1.RowCount = 1;
            this.topLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.topLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.topLayoutPanel1.Size = new System.Drawing.Size(714, 296);
            this.topLayoutPanel1.TabIndex = 0;
            // 
            // resultGB
            // 
            this.resultGB.Controls.Add(this.clearResultBtn);
            this.resultGB.Controls.Add(this.prepositionalTB);
            this.resultGB.Controls.Add(this.prepositionalLbl);
            this.resultGB.Controls.Add(this.ablativeTB);
            this.resultGB.Controls.Add(this.ablativeLbl);
            this.resultGB.Controls.Add(this.accusativeTB);
            this.resultGB.Controls.Add(this.accusativeLbl);
            this.resultGB.Controls.Add(this.dativeTB);
            this.resultGB.Controls.Add(this.dativeLbl);
            this.resultGB.Controls.Add(this.genitiveTB);
            this.resultGB.Controls.Add(this.genitiveLbl);
            this.resultGB.Controls.Add(this.declensionCB);
            this.resultGB.Controls.Add(this.restoreNominativeDeclensionBtn);
            this.resultGB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.resultGB.Location = new System.Drawing.Point(3, 305);
            this.resultGB.Name = "resultGB";
            this.resultGB.Size = new System.Drawing.Size(714, 187);
            this.resultGB.TabIndex = 1;
            this.resultGB.TabStop = false;
            this.resultGB.Text = "Результаты";
            // 
            // dipGB
            // 
            this.dipGB.Controls.Add(this.declineAppointmenOfficeBtn);
            this.dipGB.Controls.Add(this.declineOfficeBtn);
            this.dipGB.Controls.Add(this.declineAppointmenBtn);
            this.dipGB.Controls.Add(this.officeTB);
            this.dipGB.Controls.Add(this.officeLbl);
            this.dipGB.Controls.Add(this.appointmenTB);
            this.dipGB.Controls.Add(this.appointmentLbl);
            this.dipGB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dipGB.Location = new System.Drawing.Point(360, 3);
            this.dipGB.Name = "dipGB";
            this.dipGB.Size = new System.Drawing.Size(351, 290);
            this.dipGB.TabIndex = 0;
            this.dipGB.TabStop = false;
            this.dipGB.Text = "Должности и подразделения";
            // 
            // fioGB
            // 
            this.fioGB.Controls.Add(this.declineBtn);
            this.fioGB.Controls.Add(this.functionNameLbl);
            this.fioGB.Controls.Add(this.functionNameCB);
            this.fioGB.Controls.Add(this.descrFunctionTB);
            this.fioGB.Controls.Add(this.detectSexBtn);
            this.fioGB.Controls.Add(this.sexLbl);
            this.fioGB.Controls.Add(this.sexCB);
            this.fioGB.Controls.Add(this.clearFioBtn);
            this.fioGB.Controls.Add(this.splitFioBtn);
            this.fioGB.Controls.Add(this.patronymicTB);
            this.fioGB.Controls.Add(this.patronymicLbl);
            this.fioGB.Controls.Add(this.nameTB);
            this.fioGB.Controls.Add(this.nameLbl);
            this.fioGB.Controls.Add(this.surnameTB);
            this.fioGB.Controls.Add(this.surnameLbl);
            this.fioGB.Controls.Add(this.fioTextCB);
            this.fioGB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fioGB.Location = new System.Drawing.Point(3, 3);
            this.fioGB.Name = "fioGB";
            this.fioGB.Size = new System.Drawing.Size(351, 290);
            this.fioGB.TabIndex = 1;
            this.fioGB.TabStop = false;
            this.fioGB.Text = "ФИО";
            // 
            // fioTextCB
            // 
            this.fioTextCB.FormattingEnabled = true;
            this.fioTextCB.Items.AddRange(new object[] {
            "Пушкин Александр Сергеевич",
            "Ломоносов Михайло Васильевич",
            "Высоцкий Владимир Семенович",
            "Гоголь Николай Васильевич",
            "Галяутдинова Алиша Абдуллаевна",
            "Слизка Любовь Викторовна",
            "Чиковани Татьяна Кимовна",
            "Онук Сергей Викторович",
            "Ломака Владимир Михайлович",
            "Джугашвилли Иосиф Виссарионович",
            "Надоян Гриша Сережаевич",
            "Саакян Миша Артушович",
            "Мукамаев Миша Давлетянович",
            "Пыкша Татьяна Николаевна",
            "Шайхаттарова Муляуша Ирфановна",
            "Фазлыева Айгуль Нурулловна",
            "Дивов Байрам Аскер Оглы",
            "Аскер-Али-Pаде Адиль Тофик Оглы",
            "Давлетова Зульфия Нияз Кызы",
            "Уткин-Краматорский-Задунайский Гаврила Васильевич",
            "Кеннеди Джон Фиджеральд",
            "Твен Марк",
            "Амбарцумян Карен Грачи"});
            this.fioTextCB.Location = new System.Drawing.Point(6, 19);
            this.fioTextCB.Name = "fioTextCB";
            this.fioTextCB.Size = new System.Drawing.Size(339, 21);
            this.fioTextCB.TabIndex = 0;
            // 
            // surnameLbl
            // 
            this.surnameLbl.AutoSize = true;
            this.surnameLbl.Location = new System.Drawing.Point(3, 46);
            this.surnameLbl.Name = "surnameLbl";
            this.surnameLbl.Size = new System.Drawing.Size(56, 13);
            this.surnameLbl.TabIndex = 1;
            this.surnameLbl.Text = "Фамилия";
            // 
            // surnameTB
            // 
            this.surnameTB.Location = new System.Drawing.Point(68, 43);
            this.surnameTB.Name = "surnameTB";
            this.surnameTB.Size = new System.Drawing.Size(277, 20);
            this.surnameTB.TabIndex = 2;
            this.surnameTB.Text = "Пушкин";
            // 
            // nameTB
            // 
            this.nameTB.Location = new System.Drawing.Point(68, 69);
            this.nameTB.Name = "nameTB";
            this.nameTB.Size = new System.Drawing.Size(277, 20);
            this.nameTB.TabIndex = 4;
            this.nameTB.Text = "Александр";
            // 
            // nameLbl
            // 
            this.nameLbl.AutoSize = true;
            this.nameLbl.Location = new System.Drawing.Point(3, 72);
            this.nameLbl.Name = "nameLbl";
            this.nameLbl.Size = new System.Drawing.Size(29, 13);
            this.nameLbl.TabIndex = 3;
            this.nameLbl.Text = "Имя";
            // 
            // patronymicTB
            // 
            this.patronymicTB.Location = new System.Drawing.Point(68, 95);
            this.patronymicTB.Name = "patronymicTB";
            this.patronymicTB.Size = new System.Drawing.Size(277, 20);
            this.patronymicTB.TabIndex = 6;
            this.patronymicTB.Text = "Сергеевич";
            // 
            // patronymicLbl
            // 
            this.patronymicLbl.AutoSize = true;
            this.patronymicLbl.Location = new System.Drawing.Point(3, 98);
            this.patronymicLbl.Name = "patronymicLbl";
            this.patronymicLbl.Size = new System.Drawing.Size(54, 13);
            this.patronymicLbl.TabIndex = 5;
            this.patronymicLbl.Text = "Отчество";
            // 
            // splitFioBtn
            // 
            this.splitFioBtn.Location = new System.Drawing.Point(6, 121);
            this.splitFioBtn.Name = "splitFioBtn";
            this.splitFioBtn.Size = new System.Drawing.Size(168, 26);
            this.splitFioBtn.TabIndex = 7;
            this.splitFioBtn.Text = "Разбить ФИО на части";
            this.splitFioBtn.UseVisualStyleBackColor = true;
            this.splitFioBtn.Click += new System.EventHandler(this.splitFioBtn_Click);
            // 
            // clearFioBtn
            // 
            this.clearFioBtn.Location = new System.Drawing.Point(180, 121);
            this.clearFioBtn.Name = "clearFioBtn";
            this.clearFioBtn.Size = new System.Drawing.Size(165, 26);
            this.clearFioBtn.TabIndex = 8;
            this.clearFioBtn.Text = "Очистить составляющие";
            this.clearFioBtn.UseVisualStyleBackColor = true;
            this.clearFioBtn.Click += new System.EventHandler(this.clearFioBtn_Click);
            // 
            // sexCB
            // 
            this.sexCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.sexCB.FormattingEnabled = true;
            this.sexCB.Items.AddRange(new object[] {
            "мужской",
            "женский",
            "неопределен"});
            this.sexCB.Location = new System.Drawing.Point(59, 153);
            this.sexCB.Name = "sexCB";
            this.sexCB.Size = new System.Drawing.Size(115, 21);
            this.sexCB.TabIndex = 9;
            // 
            // sexLbl
            // 
            this.sexLbl.AutoSize = true;
            this.sexLbl.Location = new System.Drawing.Point(3, 156);
            this.sexLbl.Name = "sexLbl";
            this.sexLbl.Size = new System.Drawing.Size(50, 13);
            this.sexLbl.TabIndex = 10;
            this.sexLbl.Text = "Пол/род";
            // 
            // detectSexBtn
            // 
            this.detectSexBtn.Location = new System.Drawing.Point(180, 149);
            this.detectSexBtn.Name = "detectSexBtn";
            this.detectSexBtn.Size = new System.Drawing.Size(165, 26);
            this.detectSexBtn.TabIndex = 11;
            this.detectSexBtn.Text = "Определить пол";
            this.detectSexBtn.UseVisualStyleBackColor = true;
            this.detectSexBtn.Click += new System.EventHandler(this.detectSexBtn_Click);
            // 
            // descrFunctionTB
            // 
            this.descrFunctionTB.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.descrFunctionTB.Location = new System.Drawing.Point(6, 181);
            this.descrFunctionTB.Multiline = true;
            this.descrFunctionTB.Name = "descrFunctionTB";
            this.descrFunctionTB.Size = new System.Drawing.Size(339, 44);
            this.descrFunctionTB.TabIndex = 12;
            this.descrFunctionTB.Text = "Склонение фамилии, имени и отчества с явным указанием рода.";
            // 
            // functionNameLbl
            // 
            this.functionNameLbl.AutoSize = true;
            this.functionNameLbl.Location = new System.Drawing.Point(3, 234);
            this.functionNameLbl.Name = "functionNameLbl";
            this.functionNameLbl.Size = new System.Drawing.Size(143, 13);
            this.functionNameLbl.TabIndex = 14;
            this.functionNameLbl.Text = "Выбор функции склонения";
            // 
            // functionNameCB
            // 
            this.functionNameCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.functionNameCB.FormattingEnabled = true;
            this.functionNameCB.Items.AddRange(new object[] {
            "GetSNPDeclension",
            "GetSNPDeclensionAS",
            "GetSNPDeclensionFS",
            "GetSNPDeclensionFSAS",
            "GetNSDeclension",
            "GetNSDeclensionFS"});
            this.functionNameCB.Location = new System.Drawing.Point(152, 231);
            this.functionNameCB.Name = "functionNameCB";
            this.functionNameCB.Size = new System.Drawing.Size(193, 21);
            this.functionNameCB.TabIndex = 13;
            this.functionNameCB.SelectionChangeCommitted += new System.EventHandler(this.functionNameCB_SelectionChangeCommitted);
            // 
            // declineBtn
            // 
            this.declineBtn.Location = new System.Drawing.Point(6, 258);
            this.declineBtn.Name = "declineBtn";
            this.declineBtn.Size = new System.Drawing.Size(339, 26);
            this.declineBtn.TabIndex = 15;
            this.declineBtn.Text = "Склонять ФИО";
            this.declineBtn.UseVisualStyleBackColor = true;
            this.declineBtn.Click += new System.EventHandler(this.declineBtn_Click);
            // 
            // restoreNominativeDeclensionBtn
            // 
            this.restoreNominativeDeclensionBtn.Location = new System.Drawing.Point(6, 19);
            this.restoreNominativeDeclensionBtn.Name = "restoreNominativeDeclensionBtn";
            this.restoreNominativeDeclensionBtn.Size = new System.Drawing.Size(179, 26);
            this.restoreNominativeDeclensionBtn.TabIndex = 8;
            this.restoreNominativeDeclensionBtn.Text = "Восстановить именительный из";
            this.restoreNominativeDeclensionBtn.UseVisualStyleBackColor = true;
            this.restoreNominativeDeclensionBtn.Click += new System.EventHandler(this.restoreNominativeDeclensionBtn_Click);
            // 
            // declensionCB
            // 
            this.declensionCB.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.declensionCB.FormattingEnabled = true;
            this.declensionCB.Items.AddRange(new object[] {
            "родительного",
            "дательного",
            "винительного",
            "творительного",
            "предложного"});
            this.declensionCB.Location = new System.Drawing.Point(191, 23);
            this.declensionCB.Name = "declensionCB";
            this.declensionCB.Size = new System.Drawing.Size(163, 21);
            this.declensionCB.TabIndex = 14;
            // 
            // genitiveTB
            // 
            this.genitiveTB.Location = new System.Drawing.Point(144, 51);
            this.genitiveTB.Name = "genitiveTB";
            this.genitiveTB.Size = new System.Drawing.Size(561, 20);
            this.genitiveTB.TabIndex = 16;
            // 
            // genitiveLbl
            // 
            this.genitiveLbl.AutoSize = true;
            this.genitiveLbl.Location = new System.Drawing.Point(38, 54);
            this.genitiveLbl.Name = "genitiveLbl";
            this.genitiveLbl.Size = new System.Drawing.Size(100, 13);
            this.genitiveLbl.TabIndex = 15;
            this.genitiveLbl.Text = "Р (Кого/чего нет?)";
            this.genitiveLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // dativeTB
            // 
            this.dativeTB.Location = new System.Drawing.Point(144, 77);
            this.dativeTB.Name = "dativeTB";
            this.dativeTB.Size = new System.Drawing.Size(561, 20);
            this.dativeTB.TabIndex = 18;
            // 
            // dativeLbl
            // 
            this.dativeLbl.AutoSize = true;
            this.dativeLbl.Location = new System.Drawing.Point(28, 80);
            this.dativeLbl.Name = "dativeLbl";
            this.dativeLbl.Size = new System.Drawing.Size(110, 13);
            this.dativeLbl.TabIndex = 17;
            this.dativeLbl.Text = "Д (Кому/чего дать?)";
            this.dativeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // accusativeTB
            // 
            this.accusativeTB.Location = new System.Drawing.Point(144, 103);
            this.accusativeTB.Name = "accusativeTB";
            this.accusativeTB.Size = new System.Drawing.Size(561, 20);
            this.accusativeTB.TabIndex = 20;
            // 
            // accusativeLbl
            // 
            this.accusativeLbl.AutoSize = true;
            this.accusativeLbl.Location = new System.Drawing.Point(36, 106);
            this.accusativeLbl.Name = "accusativeLbl";
            this.accusativeLbl.Size = new System.Drawing.Size(102, 13);
            this.accusativeLbl.TabIndex = 19;
            this.accusativeLbl.Text = "В (Кого/что вижу?)";
            this.accusativeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // ablativeTB
            // 
            this.ablativeTB.Location = new System.Drawing.Point(144, 129);
            this.ablativeTB.Name = "ablativeTB";
            this.ablativeTB.Size = new System.Drawing.Size(561, 20);
            this.ablativeTB.TabIndex = 22;
            // 
            // ablativeLbl
            // 
            this.ablativeLbl.AutoSize = true;
            this.ablativeLbl.Location = new System.Drawing.Point(19, 132);
            this.ablativeLbl.Name = "ablativeLbl";
            this.ablativeLbl.Size = new System.Drawing.Size(119, 13);
            this.ablativeLbl.TabIndex = 21;
            this.ablativeLbl.Text = "Т (Кем/чем горжусь?)";
            this.ablativeLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // prepositionalTB
            // 
            this.prepositionalTB.Location = new System.Drawing.Point(144, 155);
            this.prepositionalTB.Name = "prepositionalTB";
            this.prepositionalTB.Size = new System.Drawing.Size(561, 20);
            this.prepositionalTB.TabIndex = 24;
            // 
            // prepositionalLbl
            // 
            this.prepositionalLbl.AutoSize = true;
            this.prepositionalLbl.Location = new System.Drawing.Point(3, 158);
            this.prepositionalLbl.Name = "prepositionalLbl";
            this.prepositionalLbl.Size = new System.Drawing.Size(135, 13);
            this.prepositionalLbl.TabIndex = 23;
            this.prepositionalLbl.Text = "П (О ком/о чем мечтаю?)";
            this.prepositionalLbl.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // clearResultBtn
            // 
            this.clearResultBtn.Location = new System.Drawing.Point(526, 19);
            this.clearResultBtn.Name = "clearResultBtn";
            this.clearResultBtn.Size = new System.Drawing.Size(179, 26);
            this.clearResultBtn.TabIndex = 25;
            this.clearResultBtn.Text = "Очистить результаты";
            this.clearResultBtn.UseVisualStyleBackColor = true;
            this.clearResultBtn.Click += new System.EventHandler(this.clearResultBtn_Click);
            // 
            // appointmenTB
            // 
            this.appointmenTB.Location = new System.Drawing.Point(6, 39);
            this.appointmenTB.Name = "appointmenTB";
            this.appointmenTB.Size = new System.Drawing.Size(339, 20);
            this.appointmenTB.TabIndex = 4;
            this.appointmenTB.Text = "Командир звена";
            // 
            // appointmentLbl
            // 
            this.appointmentLbl.AutoSize = true;
            this.appointmentLbl.Location = new System.Drawing.Point(3, 23);
            this.appointmentLbl.Name = "appointmentLbl";
            this.appointmentLbl.Size = new System.Drawing.Size(65, 13);
            this.appointmentLbl.TabIndex = 3;
            this.appointmentLbl.Text = "Должность";
            // 
            // officeTB
            // 
            this.officeTB.Location = new System.Drawing.Point(6, 85);
            this.officeTB.Multiline = true;
            this.officeTB.Name = "officeTB";
            this.officeTB.Size = new System.Drawing.Size(339, 134);
            this.officeTB.TabIndex = 6;
            this.officeTB.Text = "звено";
            // 
            // officeLbl
            // 
            this.officeLbl.AutoSize = true;
            this.officeLbl.Location = new System.Drawing.Point(3, 69);
            this.officeLbl.Name = "officeLbl";
            this.officeLbl.Size = new System.Drawing.Size(87, 13);
            this.officeLbl.TabIndex = 5;
            this.officeLbl.Text = "Подразделение";
            // 
            // declineAppointmenBtn
            // 
            this.declineAppointmenBtn.Location = new System.Drawing.Point(6, 227);
            this.declineAppointmenBtn.Name = "declineAppointmenBtn";
            this.declineAppointmenBtn.Size = new System.Drawing.Size(168, 26);
            this.declineAppointmenBtn.TabIndex = 8;
            this.declineAppointmenBtn.Text = "Склонять должность";
            this.declineAppointmenBtn.UseVisualStyleBackColor = true;
            this.declineAppointmenBtn.Click += new System.EventHandler(this.declineAppointmenBtn_Click);
            // 
            // declineOfficeBtn
            // 
            this.declineOfficeBtn.Location = new System.Drawing.Point(177, 227);
            this.declineOfficeBtn.Name = "declineOfficeBtn";
            this.declineOfficeBtn.Size = new System.Drawing.Size(168, 26);
            this.declineOfficeBtn.TabIndex = 9;
            this.declineOfficeBtn.Text = "Склонять подразделение";
            this.declineOfficeBtn.UseVisualStyleBackColor = true;
            this.declineOfficeBtn.Click += new System.EventHandler(this.declineOfficeBtn_Click);
            // 
            // declineAppointmenOfficeBtn
            // 
            this.declineAppointmenOfficeBtn.Location = new System.Drawing.Point(6, 258);
            this.declineAppointmenOfficeBtn.Name = "declineAppointmenOfficeBtn";
            this.declineAppointmenOfficeBtn.Size = new System.Drawing.Size(339, 26);
            this.declineAppointmenOfficeBtn.TabIndex = 10;
            this.declineAppointmenOfficeBtn.Text = "Склонять \"сотрудник подразделения\"";
            this.declineAppointmenOfficeBtn.UseVisualStyleBackColor = true;
            this.declineAppointmenOfficeBtn.Click += new System.EventHandler(this.declineAppointmenOfficeBtn_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(720, 495);
            this.Controls.Add(this.mainLayoutPanel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "MainForm";
            this.Text = "Тестирование библиотеки склонения";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.mainLayoutPanel1.ResumeLayout(false);
            this.topLayoutPanel1.ResumeLayout(false);
            this.resultGB.ResumeLayout(false);
            this.resultGB.PerformLayout();
            this.dipGB.ResumeLayout(false);
            this.dipGB.PerformLayout();
            this.fioGB.ResumeLayout(false);
            this.fioGB.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel mainLayoutPanel1;
        private System.Windows.Forms.TableLayoutPanel topLayoutPanel1;
        private System.Windows.Forms.GroupBox dipGB;
        private System.Windows.Forms.GroupBox fioGB;
        private System.Windows.Forms.ComboBox fioTextCB;
        private System.Windows.Forms.GroupBox resultGB;
        private System.Windows.Forms.ComboBox sexCB;
        private System.Windows.Forms.Button clearFioBtn;
        private System.Windows.Forms.Button splitFioBtn;
        private System.Windows.Forms.TextBox patronymicTB;
        private System.Windows.Forms.Label patronymicLbl;
        private System.Windows.Forms.TextBox nameTB;
        private System.Windows.Forms.Label nameLbl;
        private System.Windows.Forms.TextBox surnameTB;
        private System.Windows.Forms.Label surnameLbl;
        private System.Windows.Forms.Button declineBtn;
        private System.Windows.Forms.Label functionNameLbl;
        private System.Windows.Forms.ComboBox functionNameCB;
        private System.Windows.Forms.TextBox descrFunctionTB;
        private System.Windows.Forms.Button detectSexBtn;
        private System.Windows.Forms.Label sexLbl;
        private System.Windows.Forms.TextBox prepositionalTB;
        private System.Windows.Forms.Label prepositionalLbl;
        private System.Windows.Forms.TextBox ablativeTB;
        private System.Windows.Forms.Label ablativeLbl;
        private System.Windows.Forms.TextBox accusativeTB;
        private System.Windows.Forms.Label accusativeLbl;
        private System.Windows.Forms.TextBox dativeTB;
        private System.Windows.Forms.Label dativeLbl;
        private System.Windows.Forms.TextBox genitiveTB;
        private System.Windows.Forms.Label genitiveLbl;
        private System.Windows.Forms.ComboBox declensionCB;
        private System.Windows.Forms.Button restoreNominativeDeclensionBtn;
        private System.Windows.Forms.Button clearResultBtn;
        private System.Windows.Forms.TextBox appointmenTB;
        private System.Windows.Forms.Label appointmentLbl;
        private System.Windows.Forms.TextBox officeTB;
        private System.Windows.Forms.Label officeLbl;
        private System.Windows.Forms.Button declineAppointmenOfficeBtn;
        private System.Windows.Forms.Button declineOfficeBtn;
        private System.Windows.Forms.Button declineAppointmenBtn;
    }
}

