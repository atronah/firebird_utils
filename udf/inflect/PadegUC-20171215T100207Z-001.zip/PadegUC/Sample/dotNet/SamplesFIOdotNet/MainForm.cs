﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BLL.Declension;

namespace SamplesFIOdotNet
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void splitFioBtn_Click(object sender, EventArgs e)
        {
            string surnameNamePatronimic,surname,name,patronimic;
            surnameNamePatronimic= fioTextCB.Text;
            DeclensionBLL.GetSNM(surnameNamePatronimic, out surname, out name, out patronimic);
            surnameTB.Text = surname;
            nameTB.Text = name;
            patronymicTB.Text = patronimic;
        }

        private void ClearFIO()
        {
            surnameTB.Text = "";
            nameTB.Text = "";
            patronymicTB.Text = "";
        }

        private void clearFioBtn_Click(object sender, EventArgs e)
        {
            ClearFIO();
        }

        private void detectSexBtn_Click(object sender, EventArgs e)
        {
            string surnameNamePatronimic;
            Gender gender;
            surnameNamePatronimic = fioTextCB.Text;
            gender = DeclensionBLL.GetGender(surnameNamePatronimic);
            switch (gender)
            {
                case Gender.MasculineGender:
                    sexCB.SelectedIndex=0;
                    break;
                case Gender.FeminineGender:
                    sexCB.SelectedIndex = 1;
                    break;
                default:
                    sexCB.SelectedIndex = 2;
                    break;
            }
            MessageBox.Show(sexCB.SelectedItem.ToString());
        }

        private string GetDelensionByFunctionName(string functionName, object[] args, DeclensionCase declensionCase)
        {
            string returnValue;
            switch (functionName)
            {
                case "GetSNPDeclension":                    
                    returnValue = DeclensionBLL.GetSNPDeclension((string)args[0], (string)args[1], (string)args[2], (Gender)args[3], declensionCase);
                    break;
                case "GetSNPDeclensionAS":
                    returnValue = DeclensionBLL.GetSNPDeclensionAS((string)args[0], (string)args[1], (string)args[2], declensionCase);
                    break;
                case "GetSNPDeclensionFS":
                    returnValue = DeclensionBLL.GetSNPDeclensionFS((string)args[4], (Gender)args[3], declensionCase);
                    break;
                case "GetSNPDeclensionFSAS":
                    returnValue = DeclensionBLL.GetSNPDeclensionFSAS((string)args[4], declensionCase);
                    break;
                case "GetNSDeclension":
                    returnValue = DeclensionBLL.GetNSDeclension((string)args[1], (string)args[2], (Gender)args[3], declensionCase);
                    break;
                case "GetNSDeclensionFS":
                    returnValue = DeclensionBLL.GetNSDeclensionFS(String.Format("{0} {1}", (string)args[1], (string)args[0]), (Gender)args[3], declensionCase);
                    break;
                default:
                    returnValue ="";
                    break;
            }
            return returnValue;
        }

        private void declineBtn_Click(object sender, EventArgs e)
        {
            string surname, name, patronimic, functionName, surnameNamePatronimic;
            Gender gender;
            surname = surnameTB.Text;
            name = nameTB.Text;
            patronimic = patronymicTB.Text;
            surnameNamePatronimic = fioTextCB.Text;
            functionName = functionNameCB.Text;
             switch (sexCB.SelectedIndex)
            {
                case 0 :
                    gender=Gender.MasculineGender;
                    break;
                case 1:
                    gender = Gender.FeminineGender;
                    break;
                default:
                    gender = Gender.NotDefind;
                    break;
            }
             genitiveTB.Text = GetDelensionByFunctionName(functionName, new object[] { surname, name, patronimic, gender, surnameNamePatronimic }, DeclensionCase.Rodit);
             genitiveTB.Text = GetDelensionByFunctionName(functionName, new object[] { surname, name, patronimic, gender, surnameNamePatronimic }, DeclensionCase.Rodit);
             dativeTB.Text = GetDelensionByFunctionName(functionName, new object[] { surname, name, patronimic, gender, surnameNamePatronimic }, DeclensionCase.Datel);
             accusativeTB.Text = GetDelensionByFunctionName(functionName, new object[] { surname, name, patronimic, gender, surnameNamePatronimic }, DeclensionCase.Vinit);
             ablativeTB.Text = GetDelensionByFunctionName(functionName, new object[] { surname, name, patronimic, gender, surnameNamePatronimic }, DeclensionCase.Tvorit);
             prepositionalTB.Text = GetDelensionByFunctionName(functionName, new object[] { surname, name, patronimic, gender, surnameNamePatronimic }, DeclensionCase.Predl);
        }

        private void crearResult()
        {
            genitiveTB.Text = "";
            dativeTB.Text = "";
            accusativeTB.Text = "";
            ablativeTB.Text = "";
            prepositionalTB.Text = "";
        
        }

        private void clearResultBtn_Click(object sender, EventArgs e)
        {
            crearResult();
        }

        private void restoreNominativeDeclensionBtn_Click(object sender, EventArgs e)
        {
            string resultValue, surnameNamePatronimic;
            switch (declensionCB.SelectedIndex)
            {
                case 0 :
                    surnameNamePatronimic=genitiveTB.Text;
                    break;
                case 1:
                    surnameNamePatronimic = dativeTB.Text;
                    break;
                case 2 :
                    surnameNamePatronimic=accusativeTB.Text;
                    break;
                case 3:
                    surnameNamePatronimic = ablativeTB.Text;
                    break;
                case 4:
                    surnameNamePatronimic = prepositionalTB.Text;
                    break;
                default:
                    surnameNamePatronimic ="";
                    break;
            }
            resultValue=DeclensionBLL.GetNominativeDeclension(surnameNamePatronimic);
            MessageBox.Show(resultValue);
        }

        private void declineAppointmenBtn_Click(object sender, EventArgs e)
        {
            string appointment;
            appointment = appointmenTB.Text;
            genitiveTB.Text = DeclensionBLL.GetAppointmentDeclension(appointment, DeclensionCase.Rodit);
            genitiveTB.Text = DeclensionBLL.GetAppointmentDeclension(appointment, DeclensionCase.Rodit);
            dativeTB.Text = DeclensionBLL.GetAppointmentDeclension(appointment, DeclensionCase.Datel);
            accusativeTB.Text = DeclensionBLL.GetAppointmentDeclension(appointment, DeclensionCase.Vinit);
            ablativeTB.Text = DeclensionBLL.GetAppointmentDeclension(appointment, DeclensionCase.Tvorit);
            prepositionalTB.Text = DeclensionBLL.GetAppointmentDeclension(appointment, DeclensionCase.Predl);
        
        }

        private void declineOfficeBtn_Click(object sender, EventArgs e)
        {
            string office;
            office = officeTB.Text;
            genitiveTB.Text = DeclensionBLL.GetOfficeDeclension(office, DeclensionCase.Rodit);
            genitiveTB.Text = DeclensionBLL.GetOfficeDeclension(office, DeclensionCase.Rodit);
            dativeTB.Text = DeclensionBLL.GetOfficeDeclension(office, DeclensionCase.Datel);
            accusativeTB.Text = DeclensionBLL.GetOfficeDeclension(office, DeclensionCase.Vinit);
            ablativeTB.Text = DeclensionBLL.GetOfficeDeclension(office, DeclensionCase.Tvorit);
            prepositionalTB.Text = DeclensionBLL.GetOfficeDeclension(office, DeclensionCase.Predl);
        }

        private void declineAppointmenOfficeBtn_Click(object sender, EventArgs e)
        {
            string office, appointment;
            appointment = appointmenTB.Text;
            office = officeTB.Text;
            genitiveTB.Text = DeclensionBLL.GetAppointmentOfficeDeclension(appointment, office, DeclensionCase.Rodit);
            genitiveTB.Text = DeclensionBLL.GetAppointmentOfficeDeclension(appointment, office, DeclensionCase.Rodit);
            dativeTB.Text = DeclensionBLL.GetAppointmentOfficeDeclension(appointment, office, DeclensionCase.Datel);
            accusativeTB.Text = DeclensionBLL.GetAppointmentOfficeDeclension(appointment, office, DeclensionCase.Vinit);
            ablativeTB.Text = DeclensionBLL.GetAppointmentOfficeDeclension(appointment, office, DeclensionCase.Tvorit);
            prepositionalTB.Text = DeclensionBLL.GetAppointmentOfficeDeclension(appointment, office, DeclensionCase.Predl);
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            fioTextCB.SelectedIndex = 0;
            functionNameCB.SelectedIndex = 0;
            declensionCB.SelectedIndex = 0;
        }

        private void functionNameCB_SelectionChangeCommitted(object sender, EventArgs e)
        {
            switch (functionNameCB.SelectedIndex)
            {
                case 0:
                    descrFunctionTB.Text = "Склонение фамилии, имени и отчества с явным указанием рода.";
                    break;
                case 1:
                    descrFunctionTB.Text = "Склонениe фамилии, имени и отчества с автоматическим определением рода.";
                    break;
                case 2:
                    descrFunctionTB.Text = "Cклонениe фамилии, имени и отчества записанных одной строкой с явным указанием рода.";
                    break;
                case 3:
                    descrFunctionTB.Text = "Cклонениe фамилии, имени и отчества записанных одной строкой с автоматическим определением рода.";
                    break;
                case 4:
                    descrFunctionTB.Text = "Cклонение пары: имя, фамилия с явным указанием рода.";
                    break;
                case 5:
                    descrFunctionTB.Text = "Склонение имени и фамилии, записанных одной строкой с явным указанием рода.";
                    break;
                default:
                    descrFunctionTB.Text = "";
                    break;
            }
        }
    }
}
